import * as i0 from '@angular/core';
import { InjectionToken, Inject, Injectable, EventEmitter, Output, Input, ViewEncapsulation, Component } from '@angular/core';
import * as i1 from '@angular/common/http';
import * as i3 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i4 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import * as i2 from '@angular/platform-browser';

/** Token de inyección con la configuración efectiva (defaults aplicados). */
const POLICIA_MFA_CONFIG = new InjectionToken('POLICIA_MFA_CONFIG');
/**
 * Registra la librería MFA en el sistema consumidor.
 *
 * Uso (en app.config.ts / providers de bootstrap):
 * ```ts
 * providePoliciaMfa({ apiBaseUrl: environment.apiBaseUrl })
 * ```
 */
function providePoliciaMfa(config) {
    const efectiva = {
        apiBaseUrl: config.apiBaseUrl.replace(/\/+$/, ''),
        controlador: config.controlador?.trim() || 'Cuenta',
        issuer: config.issuer?.trim() || 'SECAD',
        deviceStorageKey: config.deviceStorageKey?.trim() || 'policia_mfa_device',
    };
    return { provide: POLICIA_MFA_CONFIG, useValue: efectiva };
}

// ─── DTOs del flujo de doble autenticación (@policia/mfa) ─────────────────────

/**
 * Cliente del flujo de doble autenticación institucional (@policia/mfa).
 *
 * Consume los endpoints MFA del backend del propio sistema
 * (.../{controlador}/MfaVerify, MfaEnrollConfirm, MfaResetRequest,
 * MfaResetConfirm), que a su vez se integran con la API 2FA central de la
 * Policía. La URL y el controlador se toman de la configuración inyectada,
 * así la misma librería sirve para cualquier sistema.
 */
class MfaService {
    http;
    cfg;
    base;
    deviceKey;
    constructor(http, cfg) {
        this.http = http;
        this.cfg = cfg;
        this.base = `${this.cfg.apiBaseUrl}/${this.cfg.controlador}`;
        this.deviceKey = this.cfg.deviceStorageKey;
    }
    // ── Gestión del deviceId ──────────────────────────────────────────────────
    /** Obtiene (o genera y persiste) el UUID del dispositivo actual. */
    getDeviceId() {
        let id = localStorage.getItem(this.deviceKey);
        if (!id) {
            id = this.uuid();
            localStorage.setItem(this.deviceKey, id);
        }
        return id;
    }
    uuid() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
            const r = Math.random() * 16 | 0;
            return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
    }
    // ── Llamadas a la API ─────────────────────────────────────────────────────
    /** Verificar código TOTP. Puede recibir deviceId para recordar el equipo. */
    verify(mfaSessionToken, code, rememberDevice) {
        return this.http.post(`${this.base}/MfaVerify`, {
            mfaSessionToken,
            code,
            rememberDevice,
            deviceId: rememberDevice ? this.getDeviceId() : null,
        }, { withCredentials: true });
    }
    /** Confirmar el primer enrolamiento (usuario escaneó QR y escribió el código). */
    enrollConfirm(mfaSessionToken, code, enrollToken) {
        return this.http.post(`${this.base}/MfaEnrollConfirm`, {
            mfaSessionToken,
            code,
            enrollToken,
        }, { withCredentials: true });
    }
    /** Solicitar código de reset al correo institucional. */
    resetRequest(mfaSessionToken) {
        return this.http.post(`${this.base}/MfaResetRequest`, {
            mfaSessionToken,
        }, { withCredentials: true });
    }
    /** Confirmar código de correo → resetea MFA → devuelve nuevo QR para enrolar. */
    resetConfirm(mfaSessionToken, code) {
        return this.http.post(`${this.base}/MfaResetConfirm`, {
            mfaSessionToken,
            code,
        }, { withCredentials: true });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.20", ngImport: i0, type: MfaService, deps: [{ token: i1.HttpClient }, { token: POLICIA_MFA_CONFIG }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.20", ngImport: i0, type: MfaService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.20", ngImport: i0, type: MfaService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [POLICIA_MFA_CONFIG]
                }] }] });

/**
 * Componente reutilizable con las modales del flujo de doble autenticación
 * institucional (@policia/mfa): enrolamiento (QR + clave manual + botón otpauth
 * de un toque), verificación TOTP, reset por correo, bloqueo y servicio caído.
 *
 * Uso desde el login de un sistema:
 * ```html
 * <pmfa-flow [challenge]="mfaChallenge" [usuario]="usuario"
 *            (autenticado)="onMfaOk($event)" (cancelado)="mfaChallenge = null">
 * </pmfa-flow>
 * ```
 * El componente NO navega ni guarda el JWT: emite el token vía `autenticado`
 * para que el sistema consumidor decida qué hacer (guardar sesión, redirigir…).
 */
class PoliciaMfaFlowComponent {
    mfaService;
    sanitizer;
    cfg;
    /** Reto MFA recibido en el paso 1 del login. Al asignarse, abre la modal correcta. */
    challenge = null;
    /** Usuario en sesión — se usa como etiqueta del enlace otpauth. */
    usuario = '';
    /** Emite el JWT definitivo cuando el 2FA se completa con éxito. */
    autenticado = new EventEmitter();
    /** Emite cuando el usuario cancela / cierra el flujo. */
    cancelado = new EventEmitter();
    // ── Estado ─────────────────────────────────────────────────────────────────
    mfaModal = null;
    mfaSessionToken = '';
    mfaQrBase64 = '';
    mfaManualKey = '';
    mfaEnrollToken = '';
    mfaOtpauthUri = null;
    mfaBloqueoHasta = '';
    mfaSvcMsg = '';
    otpDigits = ['', '', '', '', '', ''];
    mfaRememberDevice = false;
    mfaLoading = false;
    mfaError = '';
    mfaInfo = '';
    resetStep = 1;
    resetInfo = '';
    constructor(mfaService, sanitizer, cfg) {
        this.mfaService = mfaService;
        this.sanitizer = sanitizer;
        this.cfg = cfg;
    }
    ngOnChanges(changes) {
        if (changes['challenge'] && this.challenge) {
            this.handleMfaChallenge(this.challenge);
        }
    }
    // ── otpauth:// (un toque) ──────────────────────────────────────────────────
    buildOtpauthUri() {
        if (!this.mfaManualKey) {
            this.mfaOtpauthUri = null;
            return;
        }
        const secret = this.mfaManualKey.replace(/\s+/g, '').toUpperCase();
        const issuer = this.cfg.issuer;
        const label = encodeURIComponent(`${issuer}:${(this.usuario || 'usuario').trim()}`);
        const uri = `otpauth://totp/${label}?secret=${secret}&issuer=${encodeURIComponent(issuer)}&digits=6&period=30`;
        this.mfaOtpauthUri = this.sanitizer.bypassSecurityTrustUrl(uri);
    }
    // ── Decisión de modal ──────────────────────────────────────────────────────
    handleMfaChallenge(challenge) {
        this.mfaSessionToken = challenge.mfaSessionToken ?? '';
        this.clearOtp();
        this.mfaError = '';
        this.mfaInfo = '';
        const mode = (challenge.mfaMode ?? '').toLowerCase();
        if (mode === 'enroll') {
            this.mfaQrBase64 = challenge.mfaQrBase64 ?? '';
            this.mfaManualKey = challenge.mfaManualKey ?? '';
            this.mfaEnrollToken = challenge.mfaEnrollToken ?? '';
            this.buildOtpauthUri();
            this.openModal('enroll');
        }
        else if (mode === 'verify') {
            this.openModal('verify');
        }
        else if (mode === 'blocked') {
            this.mfaBloqueoHasta = challenge.bloqueoHasta ?? '';
            this.openModal('blocked');
        }
        else if (mode === 'svcdown') {
            this.mfaSvcMsg = challenge.message ?? 'El servicio de doble autenticación no está disponible.';
            this.openModal('svcdown');
        }
    }
    // ── Modales ────────────────────────────────────────────────────────────────
    openModal(m) { this.mfaModal = m; }
    closeModal() { this.mfaModal = null; }
    openResetModal() {
        this.resetStep = 1;
        this.resetInfo = '';
        this.mfaError = '';
        this.clearOtp();
        this.openModal('reset');
    }
    cancelMfa() {
        this.mfaModal = null;
        this.mfaSessionToken = '';
        this.mfaError = '';
        this.mfaInfo = '';
        this.clearOtp();
        this.cancelado.emit();
    }
    // ── OTP boxes ──────────────────────────────────────────────────────────────
    clearOtp() { this.otpDigits = ['', '', '', '', '', '']; }
    get otpCode() { return this.otpDigits.join(''); }
    onOtpInput(idx, event) {
        const input = event.target;
        const val = (input.value || '').replace(/\D/g, '').slice(-1);
        this.otpDigits[idx] = val;
        input.value = val;
        if (val && idx < 5)
            this.focusOtp(idx + 1);
        if (this.otpCode.length === 6)
            this.onOtpComplete();
    }
    onOtpKeydown(idx, event) {
        if (event.key === 'Backspace') {
            if (!this.otpDigits[idx] && idx > 0) {
                this.otpDigits[idx - 1] = '';
                this.focusOtp(idx - 1);
            }
            else {
                this.otpDigits[idx] = '';
            }
        }
        if (event.key === 'ArrowLeft' && idx > 0)
            this.focusOtp(idx - 1);
        if (event.key === 'ArrowRight' && idx < 5)
            this.focusOtp(idx + 1);
    }
    onOtpPaste(event) {
        const text = event.clipboardData?.getData('text') ?? '';
        const digits = text.replace(/\D/g, '').slice(0, 6);
        if (!digits)
            return;
        event.preventDefault();
        digits.split('').forEach((d, i) => { if (i < 6)
            this.otpDigits[i] = d; });
        this.focusOtp(Math.min(digits.length, 5));
        if (this.otpCode.length === 6)
            this.onOtpComplete();
    }
    focusOtp(idx) {
        const boxes = document.querySelectorAll('.mfa-otp-box:not([disabled])');
        if (boxes[idx])
            boxes[idx].focus();
    }
    onOtpComplete() {
        if (this.mfaModal === 'verify')
            this.submitVerify();
        if (this.mfaModal === 'enroll')
            this.submitEnroll();
        if (this.mfaModal === 'reset' && this.resetStep === 2)
            this.submitResetConfirm();
    }
    // ── Acciones MFA ───────────────────────────────────────────────────────────
    submitVerify() {
        if (this.otpCode.length !== 6) {
            this.mfaError = 'Ingrese los 6 dígitos del código.';
            return;
        }
        this.mfaLoading = true;
        this.mfaError = '';
        this.mfaService.verify(this.mfaSessionToken, this.otpCode, this.mfaRememberDevice).subscribe({
            next: r => this.handleStepResponse(r),
            error: () => { this.mfaLoading = false; this.mfaError = 'Error de comunicación. Intente nuevamente.'; }
        });
    }
    submitEnroll() {
        if (this.otpCode.length !== 6) {
            this.mfaError = 'Ingrese los 6 dígitos del código.';
            return;
        }
        this.mfaLoading = true;
        this.mfaError = '';
        this.mfaService.enrollConfirm(this.mfaSessionToken, this.otpCode, this.mfaEnrollToken).subscribe({
            next: r => this.handleStepResponse(r),
            error: () => { this.mfaLoading = false; this.mfaError = 'Error de comunicación. Intente nuevamente.'; }
        });
    }
    submitResetRequest() {
        this.mfaLoading = true;
        this.mfaError = '';
        this.resetInfo = '';
        this.mfaService.resetRequest(this.mfaSessionToken).subscribe({
            next: r => {
                this.mfaLoading = false;
                if (r.isInfo || r.success) {
                    this.resetInfo = r.message;
                    this.resetStep = 2;
                    this.clearOtp();
                }
                else {
                    this.mfaError = r.message || 'No fue posible enviar el código. Intente nuevamente.';
                }
            },
            error: () => { this.mfaLoading = false; this.mfaError = 'Error de comunicación.'; }
        });
    }
    submitResetConfirm() {
        if (this.otpCode.length !== 6) {
            this.mfaError = 'Ingrese los 6 dígitos del código.';
            return;
        }
        this.mfaLoading = true;
        this.mfaError = '';
        this.mfaService.resetConfirm(this.mfaSessionToken, this.otpCode).subscribe({
            next: r => {
                this.mfaLoading = false;
                if (!r.success) {
                    this.mfaError = r.message;
                    this.clearOtp();
                    return;
                }
                this.mfaQrBase64 = r.qrBase64 ?? '';
                this.mfaManualKey = r.manualKey ?? '';
                this.mfaEnrollToken = r.enrollToken ?? '';
                this.buildOtpauthUri();
                this.clearOtp();
                this.mfaError = '';
                this.mfaInfo = 'MFA restablecido. Escanee el nuevo QR para activar su autenticador.';
                this.openModal('enroll');
            },
            error: () => { this.mfaLoading = false; this.mfaError = 'Error de comunicación.'; }
        });
    }
    // ── Resultado final ────────────────────────────────────────────────────────
    handleStepResponse(r) {
        this.mfaLoading = false;
        if (r.bloqueoHasta) {
            this.mfaBloqueoHasta = r.bloqueoHasta;
            this.openModal('blocked');
            return;
        }
        if (!r.success) {
            this.mfaError = r.message || 'Operación no exitosa.';
            this.clearOtp();
            return;
        }
        if (r.token) {
            this.closeModal();
            this.autenticado.emit(r.token); // el sistema consumidor guarda sesión y navega
        }
    }
    trackByIdx(idx) { return idx; }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.20", ngImport: i0, type: PoliciaMfaFlowComponent, deps: [{ token: MfaService }, { token: i2.DomSanitizer }, { token: POLICIA_MFA_CONFIG }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.20", type: PoliciaMfaFlowComponent, isStandalone: true, selector: "pmfa-flow", inputs: { challenge: "challenge", usuario: "usuario" }, outputs: { autenticado: "autenticado", cancelado: "cancelado" }, usesOnChanges: true, ngImport: i0, template: "<!-- @policia/mfa \u2014 modales del flujo de doble autenticaci\u00F3n (enroll/verify/reset/blocked/svcdown).\n     Extra\u00EDdo verbatim del login de SECAD para reutilizarlo en todos los sistemas. -->\n<div *ngIf=\"mfaModal\" class=\"mfa-overlay\" role=\"dialog\" aria-modal=\"true\">\n\n  <!-- \u2500\u2500 MODAL: ENROLAMIENTO (primera vez o re-enrolamiento) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div *ngIf=\"mfaModal === 'enroll'\" class=\"mfa-card mfa-card--lg\">\n    <div class=\"mfa-card__head\">\n      <span class=\"mfa-icon\">\uD83D\uDD10</span>\n      <div>\n        <div class=\"mfa-card__title\">Activar doble autenticaci\u00F3n (TOTP)</div>\n        <div class=\"mfa-card__sub\">Recomendado: Google Authenticator, Microsoft Authenticator, Authy</div>\n      </div>\n      <button class=\"mfa-close-btn\" type=\"button\"\n              (click)=\"cancelMfa()\"\n              [disabled]=\"mfaLoading\"\n              title=\"Cerrar y volver al inicio de sesi\u00F3n\"\n              aria-label=\"Cerrar\">\n        <i class=\"fa-solid fa-xmark\"></i>\n      </button>\n    </div>\n\n    <div class=\"mfa-card__body mfa-enroll-grid\">\n\n      <!-- Columna izquierda: QR + clave manual -->\n      <div class=\"mfa-enroll-col\">\n        <p class=\"mfa-step-label\">1) Escanee el c\u00F3digo QR</p>\n        <p class=\"mfa-help\">Abra su app de autenticaci\u00F3n y agregue una cuenta con el c\u00F3digo QR.</p>\n        <div class=\"mfa-qr-wrap\">\n          <img *ngIf=\"mfaQrBase64\" [src]=\"'data:image/png;base64,' + mfaQrBase64\"\n               class=\"mfa-qr\" alt=\"C\u00F3digo QR TOTP\">\n          <p *ngIf=\"!mfaQrBase64\" class=\"mfa-error-inline\">No se pudo generar el QR. Reintente desde el inicio.</p>\n        </div>\n        <div class=\"mfa-manual-wrap\" *ngIf=\"mfaManualKey\">\n          <p class=\"mfa-step-label mfa-step-label--sm\">Clave manual (no la comparta)</p>\n          <code class=\"mfa-manual-key\">{{ mfaManualKey }}</code>\n        </div>\n\n        <!-- Un toque para agregar la cuenta cuando SECAD se abre en el mismo\n             celular que tiene la app de autenticaci\u00F3n (no se puede escanear la\n             propia pantalla). -->\n        <a *ngIf=\"mfaOtpauthUri\" class=\"mfa-otpauth-btn\" [href]=\"mfaOtpauthUri\">\n          <i class=\"fa-solid fa-mobile-screen-button\"></i>\n          \u00BFEn un celular? Toque para agregarla a su app\n        </a>\n      </div>\n\n      <!-- Columna derecha: OTP -->\n      <div class=\"mfa-enroll-col\">\n        <p class=\"mfa-step-label\">2) Ingrese el c\u00F3digo de 6 d\u00EDgitos</p>\n        <p class=\"mfa-help\">Genere el c\u00F3digo en su app y conf\u00EDrmelo aqu\u00ED. Si falla, revise que el celular tenga hora autom\u00E1tica.</p>\n\n        <div class=\"mfa-otp-wrap\">\n          <input *ngFor=\"let d of otpDigits; let i = index; trackBy: trackByIdx\"\n                 class=\"mfa-otp-box\" type=\"text\" inputmode=\"numeric\"\n                 maxlength=\"1\" [value]=\"d\"\n                 [attr.autocomplete]=\"i === 0 ? 'one-time-code' : 'off'\"\n                 (input)=\"onOtpInput(i, $event)\"\n                 (keydown)=\"onOtpKeydown(i, $event)\"\n                 (paste)=\"onOtpPaste($event)\"\n                 [disabled]=\"mfaLoading\">\n        </div>\n\n        <p *ngIf=\"mfaError\" class=\"mfa-error-inline\">{{ mfaError }}</p>\n        <p *ngIf=\"mfaInfo\"  class=\"mfa-info-inline\">{{ mfaInfo }}</p>\n\n        <div class=\"mfa-actions\">\n          <button class=\"mfa-btn mfa-btn--primary\" (click)=\"submitEnroll()\" [disabled]=\"mfaLoading || otpCode.length < 6\">\n            <span *ngIf=\"!mfaLoading\">Confirmar y activar</span>\n            <span *ngIf=\"mfaLoading\"><i class=\"fa fa-spinner fa-spin\"></i> Procesando...</span>\n          </button>\n          <button class=\"mfa-btn mfa-btn--ghost\" (click)=\"cancelMfa()\" [disabled]=\"mfaLoading\">\n            Cancelar\n          </button>\n        </div>\n\n        <div class=\"mfa-note\">\n          <i class=\"fa-solid fa-triangle-exclamation\"></i>\n          Si cambia de celular, deber\u00E1 re-enrolar el autenticador.\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <!-- \u2500\u2500 MODAL: VERIFICACI\u00D3N (usuario ya enrolado) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div *ngIf=\"mfaModal === 'verify'\" class=\"mfa-card\">\n    <div class=\"mfa-card__head\">\n      <span class=\"mfa-icon\">\uD83D\uDEE1\uFE0F</span>\n      <div>\n        <div class=\"mfa-card__title\">Verificaci\u00F3n de seguridad</div>\n        <div class=\"mfa-card__sub\">Use el c\u00F3digo de su app de autenticaci\u00F3n</div>\n      </div>\n      <button class=\"mfa-close-btn\" type=\"button\"\n              (click)=\"cancelMfa()\"\n              [disabled]=\"mfaLoading\"\n              title=\"Cerrar y volver al inicio de sesi\u00F3n\"\n              aria-label=\"Cerrar\">\n        <i class=\"fa-solid fa-xmark\"></i>\n      </button>\n    </div>\n\n    <div class=\"mfa-card__body\">\n      <p class=\"mfa-help\">Ingrese el c\u00F3digo de <strong>6 d\u00EDgitos</strong> generado por su app.</p>\n\n      <div class=\"mfa-otp-wrap\">\n        <input *ngFor=\"let d of otpDigits; let i = index; trackBy: trackByIdx\"\n               class=\"mfa-otp-box\" type=\"text\" inputmode=\"numeric\"\n               maxlength=\"1\" [value]=\"d\"\n               [attr.autocomplete]=\"i === 0 ? 'one-time-code' : 'off'\"\n               (input)=\"onOtpInput(i, $event)\"\n               (keydown)=\"onOtpKeydown(i, $event)\"\n               (paste)=\"onOtpPaste($event)\"\n               [disabled]=\"mfaLoading\">\n      </div>\n\n      <p *ngIf=\"mfaError\" class=\"mfa-error-inline\">{{ mfaError }}</p>\n\n      <!-- Recordar dispositivo -->\n      <label class=\"mfa-remember-label\">\n        <input type=\"checkbox\" [(ngModel)]=\"mfaRememberDevice\">\n        <span>Recordar este equipo por 30 d\u00EDas</span>\n      </label>\n\n      <div class=\"mfa-actions\">\n        <button class=\"mfa-btn mfa-btn--primary\" (click)=\"submitVerify()\" [disabled]=\"mfaLoading || otpCode.length < 6\">\n          <span *ngIf=\"!mfaLoading\"><i class=\"fa fa-shield-halved\"></i> Verificar</span>\n          <span *ngIf=\"mfaLoading\"><i class=\"fa fa-spinner fa-spin\"></i> Verificando...</span>\n        </button>\n      </div>\n\n      <div class=\"mfa-divider\"></div>\n\n      <div class=\"mfa-lost-link\">\n        <button type=\"button\" (click)=\"openResetModal()\">\n          <i class=\"fa-solid fa-rotate-left\"></i> \u00BFPerdi\u00F3 su autenticador? Restabl\u00E9zcalo\n        </button>\n      </div>\n    </div>\n  </div>\n\n  <!-- \u2500\u2500 MODAL: RESET (recuperaci\u00F3n por correo) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div *ngIf=\"mfaModal === 'reset'\" class=\"mfa-card\">\n    <div class=\"mfa-card__head\">\n      <span class=\"mfa-icon\">\uD83D\uDCE7</span>\n      <div>\n        <div class=\"mfa-card__title\">Restablecer autenticador por correo</div>\n        <div class=\"mfa-card__sub\">Enviaremos un c\u00F3digo a su correo institucional</div>\n      </div>\n      <button class=\"mfa-close-btn\" type=\"button\"\n              (click)=\"openModal('verify')\"\n              [disabled]=\"mfaLoading\"\n              title=\"Volver a la verificaci\u00F3n\"\n              aria-label=\"Cerrar\">\n        <i class=\"fa-solid fa-xmark\"></i>\n      </button>\n    </div>\n\n    <div class=\"mfa-card__body\">\n\n      <!-- Paso 1: solicitar el c\u00F3digo -->\n      <div *ngIf=\"resetStep === 1\">\n        <p class=\"mfa-help\">\n          El c\u00F3digo dura <strong>5 minutos</strong>. Por seguridad, luego de validarlo habr\u00E1\n          una espera breve antes de poder enrolar nuevamente.\n        </p>\n        <p *ngIf=\"mfaError\" class=\"mfa-error-inline\">{{ mfaError }}</p>\n        <div class=\"mfa-actions\">\n          <button class=\"mfa-btn mfa-btn--primary\" (click)=\"submitResetRequest()\" [disabled]=\"mfaLoading\">\n            <span *ngIf=\"!mfaLoading\"><i class=\"fa fa-envelope\"></i> Enviar c\u00F3digo al correo</span>\n            <span *ngIf=\"mfaLoading\"><i class=\"fa fa-spinner fa-spin\"></i> Enviando...</span>\n          </button>\n        </div>\n      </div>\n\n      <!-- Paso 2: ingresar el c\u00F3digo recibido -->\n      <div *ngIf=\"resetStep === 2\">\n        <p class=\"mfa-help\">Ingrese el c\u00F3digo de <strong>6 d\u00EDgitos</strong> que lleg\u00F3 a su correo.</p>\n        <p *ngIf=\"resetInfo\" class=\"mfa-info-inline\">{{ resetInfo }}</p>\n\n        <div class=\"mfa-otp-wrap\">\n          <input *ngFor=\"let d of otpDigits; let i = index; trackBy: trackByIdx\"\n                 class=\"mfa-otp-box\" type=\"text\" inputmode=\"numeric\"\n                 maxlength=\"1\" [value]=\"d\"\n                 [attr.autocomplete]=\"i === 0 ? 'one-time-code' : 'off'\"\n                 (input)=\"onOtpInput(i, $event)\"\n                 (keydown)=\"onOtpKeydown(i, $event)\"\n                 (paste)=\"onOtpPaste($event)\"\n                 [disabled]=\"mfaLoading\">\n        </div>\n\n        <p *ngIf=\"mfaError\" class=\"mfa-error-inline\">{{ mfaError }}</p>\n\n        <div class=\"mfa-actions\">\n          <button class=\"mfa-btn mfa-btn--primary\" (click)=\"submitResetConfirm()\"\n                  [disabled]=\"mfaLoading || otpCode.length < 6\">\n            <span *ngIf=\"!mfaLoading\">Confirmar c\u00F3digo</span>\n            <span *ngIf=\"mfaLoading\"><i class=\"fa fa-spinner fa-spin\"></i> Verificando...</span>\n          </button>\n          <button class=\"mfa-btn mfa-btn--ghost\" (click)=\"resetStep = 1; clearOtp(); mfaError = ''\"\n                  [disabled]=\"mfaLoading\">\n            \u2190 Volver\n          </button>\n        </div>\n      </div>\n\n      <div class=\"mfa-divider\"></div>\n      <div class=\"mfa-lost-link\">\n        <button type=\"button\" (click)=\"openModal('verify')\">\u2190 Volver a la verificaci\u00F3n</button>\n      </div>\n    </div>\n  </div>\n\n  <!-- \u2500\u2500 MODAL: BLOQUEADO \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div *ngIf=\"mfaModal === 'blocked'\" class=\"mfa-card mfa-card--danger\">\n    <div class=\"mfa-card__head\">\n      <span class=\"mfa-icon\">\u26D4</span>\n      <div>\n        <div class=\"mfa-card__title\">Acceso temporalmente bloqueado</div>\n        <div class=\"mfa-card__sub\">Se detectaron intentos fallidos</div>\n      </div>\n      <button class=\"mfa-close-btn\" type=\"button\"\n              (click)=\"cancelMfa()\"\n              title=\"Volver al inicio de sesi\u00F3n\"\n              aria-label=\"Cerrar\">\n        <i class=\"fa-solid fa-xmark\"></i>\n      </button>\n    </div>\n\n    <div class=\"mfa-card__body\">\n      <p class=\"mfa-help\">\n        Su cuenta tiene un bloqueo de seguridad activo por m\u00FAltiples intentos fallidos.\n        Espere a que expire el tiempo de bloqueo e intente nuevamente.\n      </p>\n      <div class=\"mfa-blocked-until\">\n        <i class=\"fa-solid fa-clock\"></i>\n        Bloqueado hasta: <strong>{{ mfaBloqueoHasta || 'No disponible' }}</strong>\n      </div>\n      <div class=\"mfa-actions mfa-actions--center\">\n        <button class=\"mfa-btn mfa-btn--ghost\" (click)=\"cancelMfa()\">\n          Volver al inicio de sesi\u00F3n\n        </button>\n      </div>\n    </div>\n  </div>\n\n  <!-- \u2500\u2500 MODAL: SERVICIO CA\u00CDDO \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div *ngIf=\"mfaModal === 'svcdown'\" class=\"mfa-card mfa-card--warning\">\n    <div class=\"mfa-card__head\">\n      <span class=\"mfa-icon\">\u26A0\uFE0F</span>\n      <div>\n        <div class=\"mfa-card__title\">Servicio de doble autenticaci\u00F3n no disponible</div>\n        <div class=\"mfa-card__sub\">No es posible iniciar sesi\u00F3n en este momento</div>\n      </div>\n      <button class=\"mfa-close-btn\" type=\"button\"\n              (click)=\"cancelMfa()\"\n              title=\"Volver al inicio de sesi\u00F3n\"\n              aria-label=\"Cerrar\">\n        <i class=\"fa-solid fa-xmark\"></i>\n      </button>\n    </div>\n\n    <div class=\"mfa-card__body\">\n      <p class=\"mfa-help\">\n        El servicio de <strong>Doble Autenticaci\u00F3n (2FA/MFA)</strong> est\u00E1 presentando\n        fallas o no se pudo establecer conexi\u00F3n. Por pol\u00EDtica de seguridad, el acceso\n        queda temporalmente restringido hasta que el servicio se restablezca.\n      </p>\n      <p *ngIf=\"mfaSvcMsg\" class=\"mfa-error-inline\">{{ mfaSvcMsg }}</p>\n      <div class=\"mfa-note mfa-note--warning\">\n        <strong>Acci\u00F3n requerida:</strong> Contacte al Administrador del sistema o al t\u00E9cnico GUTIC de su unidad.\n      </div>\n      <div class=\"mfa-actions mfa-actions--center\">\n        <button class=\"mfa-btn mfa-btn--ghost\" (click)=\"cancelMfa()\">\n          Volver al inicio de sesi\u00F3n\n        </button>\n      </div>\n    </div>\n  </div>\n\n</div><!-- /mfa-overlay -->\n", styles: ["@charset \"UTF-8\";.mfa-overlay{position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;background:#02061799;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);padding:16px;animation:mfaOverlayIn .2s ease-out}@keyframes mfaOverlayIn{0%{opacity:0}to{opacity:1}}.mfa-card{background:#fff;border:1px solid rgba(255,255,255,.12);border-radius:18px;box-shadow:0 30px 80px #02061761;width:100%;max-width:500px;max-height:90vh;overflow-y:auto;animation:mfaCardIn .22s ease-out}.mfa-card--lg{max-width:840px}.mfa-card--danger .mfa-card__head{background:linear-gradient(135deg,#7f1d1d,#dc2626)}.mfa-card--warning .mfa-card__head{background:linear-gradient(135deg,#005478,#0e1f38)}.mfa-card__head{display:flex;align-items:center;gap:14px;padding:18px 50px 18px 22px;background:linear-gradient(135deg,#03173d,#1c45b4);border-radius:18px 18px 0 0;color:#fff;position:relative}.mfa-card__title{font-weight:800;font-size:calc(15px * var(--font-size-scale, 1));line-height:1.2;letter-spacing:.1px}.mfa-card__sub{font-size:calc(12px * var(--font-size-scale, 1));opacity:.72;margin-top:3px;font-weight:400}.mfa-card__body{padding:22px}.mfa-close-btn{position:absolute;top:12px;right:12px;width:32px;height:32px;border:none;border-radius:50%;background:#ffffff26;color:#ffffffd9;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:15px;line-height:1;transition:background .15s,color .15s,transform .12s;flex-shrink:0}.mfa-close-btn:hover:not(:disabled){background:#ffffff47;color:#fff;transform:scale(1.08)}.mfa-close-btn:active:not(:disabled){transform:scale(.95)}.mfa-close-btn:disabled{opacity:.35;cursor:not-allowed}@keyframes mfaCardIn{0%{opacity:0;transform:translateY(10px) scale(.99)}to{opacity:1;transform:translateY(0) scale(1)}}.mfa-icon{font-size:1.5rem;flex-shrink:0;line-height:1}.mfa-help{color:var(--policia-neutral-oscuro, #53565a);font-size:calc(13px * var(--font-size-scale, 1));line-height:1.5;margin:0 0 14px}.mfa-step-label{font-weight:800;font-size:calc(13px * var(--font-size-scale, 1));color:var(--policia-medio, #002a66);margin:0 0 6px;letter-spacing:.1px}.mfa-step-label--sm{font-size:calc(12px * var(--font-size-scale, 1));margin-top:14px}.mfa-enroll-grid{display:grid;grid-template-columns:1fr 1fr;gap:22px}@media(max-width:640px){.mfa-enroll-grid{grid-template-columns:1fr}}.mfa-qr-wrap{text-align:center;margin-bottom:14px}.mfa-qr{max-width:210px;width:100%;border-radius:var(--ui-radius, 14px);border:2px solid rgba(21,27,59,.14);padding:8px;background:#fff;box-shadow:0 6px 16px #0206171a}.mfa-manual-wrap{margin-top:12px}.mfa-manual-key{display:block;background:var(--policia-oscuro, #151b3b);color:#cdff00;font-family:Courier New,monospace;font-size:.82rem;padding:10px 14px;border-radius:var(--ui-radius-sm, 10px);word-break:break-all;margin-top:4px;letter-spacing:.05em;border:1px solid rgba(205,255,0,.2)}.mfa-otpauth-btn{display:inline-flex;align-items:center;gap:8px;margin-top:12px;padding:9px 14px;border-radius:var(--ui-radius-sm, 10px);border:1px solid var(--ui-border, rgba(21, 27, 59, .18));background:var(--ui-surface, #fff);color:var(--policia-oscuro, #151b3b);font-size:.82rem;font-weight:600;text-decoration:none;cursor:pointer;transition:background .15s,border-color .15s}.mfa-otpauth-btn i{color:var(--policia-azul, #2563eb)}.mfa-otpauth-btn:hover{background:var(--policia-gradiente-soft, rgba(37, 99, 235, .08));border-color:var(--policia-azul, #2563eb)}html.dark-mode .mfa-otpauth-btn{background:#ffffff0d;border-color:#ffffff26;color:#e4e7ebe6}.mfa-otp-wrap{display:flex;gap:8px;justify-content:center;margin:18px 0}.mfa-otp-box{width:48px;height:56px;text-align:center;font-size:1.5rem;font-weight:800;border-radius:12px;border:1.5px solid rgba(21,27,59,.18);background:#fff;color:var(--policia-medio, #002a66);outline:none;transition:border-color .15s ease,box-shadow .15s ease;caret-color:transparent;font-family:Montserrat,sans-serif}.mfa-otp-box:focus{border-color:#08a6cbbf;box-shadow:0 0 0 4px #08a6cb2e}.mfa-otp-box:hover:not(:focus):not(:disabled){border-color:#151b3b4d}.mfa-otp-box:disabled{opacity:.5;cursor:not-allowed}@media(max-width:420px){.mfa-otp-box{width:40px;height:50px;font-size:1.25rem}}.mfa-remember-label{display:flex;align-items:center;gap:10px;font-size:calc(13px * var(--font-size-scale, 1));color:var(--policia-neutral-oscuro, #53565a);cursor:pointer;margin-bottom:16px;padding:10px 12px;border:1px solid rgba(21,27,59,.12);border-radius:999px;background:#151b3b08;transition:background .15s ease,border-color .15s ease}.mfa-remember-label:hover{background:#08a6cb0f;border-color:#08a6cb40}.mfa-remember-label input[type=checkbox]{width:17px;height:17px;accent-color:#cdff00;cursor:pointer;border-radius:5px}.mfa-actions{display:flex;flex-direction:column;gap:10px;margin-top:18px}.mfa-actions--center{align-items:center}.mfa-btn{display:flex;align-items:center;justify-content:center;gap:8px;padding:0 20px;height:42px;border-radius:var(--btn-radius, 12px);border:1.5px solid transparent;font-size:calc(14px * var(--font-size-scale, 1));font-weight:800;letter-spacing:.2px;cursor:pointer;transition:transform .15s ease,box-shadow .15s ease,background .15s ease;font-family:Montserrat,sans-serif}.mfa-btn:disabled{opacity:.5;cursor:not-allowed;transform:none!important}.mfa-btn:focus-visible{outline:none;box-shadow:0 0 0 4px #08a6cb38}.mfa-btn--primary{background:#cdff00;color:#151b3b;border-color:#cdff008c;box-shadow:0 8px 20px #02061724}.mfa-btn--primary:hover:not(:disabled){background:#d8ff2a;transform:translateY(-1px);box-shadow:0 12px 26px #0206172e}.mfa-btn--primary:active:not(:disabled){transform:translateY(0);box-shadow:none}.mfa-btn--ghost{background:var(--policia-medio, #002a66);color:#fff;border-color:#ffffff24;box-shadow:0 4px 12px #0206172e}.mfa-btn--ghost:hover:not(:disabled){background:#003580;transform:translateY(-1px);box-shadow:0 8px 18px #02061738}.mfa-btn--ghost:active:not(:disabled){transform:translateY(0)}.mfa-error-inline{background:#ef44441a;color:#991b1b;border:1px solid rgba(239,68,68,.28);border-left:3px solid #ef4444;border-radius:var(--ui-radius-sm, 10px);padding:10px 14px;font-size:calc(12px * var(--font-size-scale, 1));font-weight:600;margin:10px 0}.mfa-info-inline{background:#08a6cb1a;color:var(--policia-medio, #002a66);border:1px solid rgba(8,166,203,.3);border-left:3px solid #08a6cb;border-radius:var(--ui-radius-sm, 10px);padding:10px 14px;font-size:calc(12px * var(--font-size-scale, 1));font-weight:600;margin:10px 0}.mfa-divider{height:1px;background:#151b3b1a;margin:20px 0}.mfa-lost-link{text-align:center}.mfa-lost-link button{background:none;border:none;color:var(--policia-cielo, #08a6cb);font-size:calc(12px * var(--font-size-scale, 1));font-weight:700;cursor:pointer;padding:0;font-family:Montserrat,sans-serif;transition:color .15s ease;letter-spacing:.1px}.mfa-lost-link button i{margin-right:5px}.mfa-lost-link button:hover{color:var(--policia-claro, #1c45b4);text-decoration:underline}.mfa-note{background:#b36e1a14;border:1px solid rgba(179,110,26,.25);border-left:3px solid #b36e1a;border-radius:var(--ui-radius-sm, 10px);padding:10px 14px;font-size:calc(12px * var(--font-size-scale, 1));color:#7a3f05;margin-top:16px}.mfa-note i{margin-right:6px;color:#b36e1a}.mfa-note--warning{background:#b36e1a1a;color:#92400e}.mfa-blocked-until{display:flex;align-items:center;gap:10px;background:#ef444414;border:1px solid rgba(239,68,68,.22);border-left:3px solid #ef4444;border-radius:var(--ui-radius, 14px);padding:14px 18px;font-size:calc(14px * var(--font-size-scale, 1));color:#7f1d1d;margin:14px 0 20px;font-weight:600}.mfa-blocked-until i{color:#ef4444;font-size:1.1rem;flex-shrink:0}.mfa-card{scrollbar-width:thin;scrollbar-color:rgba(8,166,203,.25) transparent}.mfa-card::-webkit-scrollbar{width:5px}.mfa-card::-webkit-scrollbar-track{background:transparent}.mfa-card::-webkit-scrollbar-thumb{background:#08a6cb4d;border-radius:999px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.20", ngImport: i0, type: PoliciaMfaFlowComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pmfa-flow', standalone: true, imports: [CommonModule, FormsModule], encapsulation: ViewEncapsulation.None, template: "<!-- @policia/mfa \u2014 modales del flujo de doble autenticaci\u00F3n (enroll/verify/reset/blocked/svcdown).\n     Extra\u00EDdo verbatim del login de SECAD para reutilizarlo en todos los sistemas. -->\n<div *ngIf=\"mfaModal\" class=\"mfa-overlay\" role=\"dialog\" aria-modal=\"true\">\n\n  <!-- \u2500\u2500 MODAL: ENROLAMIENTO (primera vez o re-enrolamiento) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div *ngIf=\"mfaModal === 'enroll'\" class=\"mfa-card mfa-card--lg\">\n    <div class=\"mfa-card__head\">\n      <span class=\"mfa-icon\">\uD83D\uDD10</span>\n      <div>\n        <div class=\"mfa-card__title\">Activar doble autenticaci\u00F3n (TOTP)</div>\n        <div class=\"mfa-card__sub\">Recomendado: Google Authenticator, Microsoft Authenticator, Authy</div>\n      </div>\n      <button class=\"mfa-close-btn\" type=\"button\"\n              (click)=\"cancelMfa()\"\n              [disabled]=\"mfaLoading\"\n              title=\"Cerrar y volver al inicio de sesi\u00F3n\"\n              aria-label=\"Cerrar\">\n        <i class=\"fa-solid fa-xmark\"></i>\n      </button>\n    </div>\n\n    <div class=\"mfa-card__body mfa-enroll-grid\">\n\n      <!-- Columna izquierda: QR + clave manual -->\n      <div class=\"mfa-enroll-col\">\n        <p class=\"mfa-step-label\">1) Escanee el c\u00F3digo QR</p>\n        <p class=\"mfa-help\">Abra su app de autenticaci\u00F3n y agregue una cuenta con el c\u00F3digo QR.</p>\n        <div class=\"mfa-qr-wrap\">\n          <img *ngIf=\"mfaQrBase64\" [src]=\"'data:image/png;base64,' + mfaQrBase64\"\n               class=\"mfa-qr\" alt=\"C\u00F3digo QR TOTP\">\n          <p *ngIf=\"!mfaQrBase64\" class=\"mfa-error-inline\">No se pudo generar el QR. Reintente desde el inicio.</p>\n        </div>\n        <div class=\"mfa-manual-wrap\" *ngIf=\"mfaManualKey\">\n          <p class=\"mfa-step-label mfa-step-label--sm\">Clave manual (no la comparta)</p>\n          <code class=\"mfa-manual-key\">{{ mfaManualKey }}</code>\n        </div>\n\n        <!-- Un toque para agregar la cuenta cuando SECAD se abre en el mismo\n             celular que tiene la app de autenticaci\u00F3n (no se puede escanear la\n             propia pantalla). -->\n        <a *ngIf=\"mfaOtpauthUri\" class=\"mfa-otpauth-btn\" [href]=\"mfaOtpauthUri\">\n          <i class=\"fa-solid fa-mobile-screen-button\"></i>\n          \u00BFEn un celular? Toque para agregarla a su app\n        </a>\n      </div>\n\n      <!-- Columna derecha: OTP -->\n      <div class=\"mfa-enroll-col\">\n        <p class=\"mfa-step-label\">2) Ingrese el c\u00F3digo de 6 d\u00EDgitos</p>\n        <p class=\"mfa-help\">Genere el c\u00F3digo en su app y conf\u00EDrmelo aqu\u00ED. Si falla, revise que el celular tenga hora autom\u00E1tica.</p>\n\n        <div class=\"mfa-otp-wrap\">\n          <input *ngFor=\"let d of otpDigits; let i = index; trackBy: trackByIdx\"\n                 class=\"mfa-otp-box\" type=\"text\" inputmode=\"numeric\"\n                 maxlength=\"1\" [value]=\"d\"\n                 [attr.autocomplete]=\"i === 0 ? 'one-time-code' : 'off'\"\n                 (input)=\"onOtpInput(i, $event)\"\n                 (keydown)=\"onOtpKeydown(i, $event)\"\n                 (paste)=\"onOtpPaste($event)\"\n                 [disabled]=\"mfaLoading\">\n        </div>\n\n        <p *ngIf=\"mfaError\" class=\"mfa-error-inline\">{{ mfaError }}</p>\n        <p *ngIf=\"mfaInfo\"  class=\"mfa-info-inline\">{{ mfaInfo }}</p>\n\n        <div class=\"mfa-actions\">\n          <button class=\"mfa-btn mfa-btn--primary\" (click)=\"submitEnroll()\" [disabled]=\"mfaLoading || otpCode.length < 6\">\n            <span *ngIf=\"!mfaLoading\">Confirmar y activar</span>\n            <span *ngIf=\"mfaLoading\"><i class=\"fa fa-spinner fa-spin\"></i> Procesando...</span>\n          </button>\n          <button class=\"mfa-btn mfa-btn--ghost\" (click)=\"cancelMfa()\" [disabled]=\"mfaLoading\">\n            Cancelar\n          </button>\n        </div>\n\n        <div class=\"mfa-note\">\n          <i class=\"fa-solid fa-triangle-exclamation\"></i>\n          Si cambia de celular, deber\u00E1 re-enrolar el autenticador.\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <!-- \u2500\u2500 MODAL: VERIFICACI\u00D3N (usuario ya enrolado) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div *ngIf=\"mfaModal === 'verify'\" class=\"mfa-card\">\n    <div class=\"mfa-card__head\">\n      <span class=\"mfa-icon\">\uD83D\uDEE1\uFE0F</span>\n      <div>\n        <div class=\"mfa-card__title\">Verificaci\u00F3n de seguridad</div>\n        <div class=\"mfa-card__sub\">Use el c\u00F3digo de su app de autenticaci\u00F3n</div>\n      </div>\n      <button class=\"mfa-close-btn\" type=\"button\"\n              (click)=\"cancelMfa()\"\n              [disabled]=\"mfaLoading\"\n              title=\"Cerrar y volver al inicio de sesi\u00F3n\"\n              aria-label=\"Cerrar\">\n        <i class=\"fa-solid fa-xmark\"></i>\n      </button>\n    </div>\n\n    <div class=\"mfa-card__body\">\n      <p class=\"mfa-help\">Ingrese el c\u00F3digo de <strong>6 d\u00EDgitos</strong> generado por su app.</p>\n\n      <div class=\"mfa-otp-wrap\">\n        <input *ngFor=\"let d of otpDigits; let i = index; trackBy: trackByIdx\"\n               class=\"mfa-otp-box\" type=\"text\" inputmode=\"numeric\"\n               maxlength=\"1\" [value]=\"d\"\n               [attr.autocomplete]=\"i === 0 ? 'one-time-code' : 'off'\"\n               (input)=\"onOtpInput(i, $event)\"\n               (keydown)=\"onOtpKeydown(i, $event)\"\n               (paste)=\"onOtpPaste($event)\"\n               [disabled]=\"mfaLoading\">\n      </div>\n\n      <p *ngIf=\"mfaError\" class=\"mfa-error-inline\">{{ mfaError }}</p>\n\n      <!-- Recordar dispositivo -->\n      <label class=\"mfa-remember-label\">\n        <input type=\"checkbox\" [(ngModel)]=\"mfaRememberDevice\">\n        <span>Recordar este equipo por 30 d\u00EDas</span>\n      </label>\n\n      <div class=\"mfa-actions\">\n        <button class=\"mfa-btn mfa-btn--primary\" (click)=\"submitVerify()\" [disabled]=\"mfaLoading || otpCode.length < 6\">\n          <span *ngIf=\"!mfaLoading\"><i class=\"fa fa-shield-halved\"></i> Verificar</span>\n          <span *ngIf=\"mfaLoading\"><i class=\"fa fa-spinner fa-spin\"></i> Verificando...</span>\n        </button>\n      </div>\n\n      <div class=\"mfa-divider\"></div>\n\n      <div class=\"mfa-lost-link\">\n        <button type=\"button\" (click)=\"openResetModal()\">\n          <i class=\"fa-solid fa-rotate-left\"></i> \u00BFPerdi\u00F3 su autenticador? Restabl\u00E9zcalo\n        </button>\n      </div>\n    </div>\n  </div>\n\n  <!-- \u2500\u2500 MODAL: RESET (recuperaci\u00F3n por correo) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div *ngIf=\"mfaModal === 'reset'\" class=\"mfa-card\">\n    <div class=\"mfa-card__head\">\n      <span class=\"mfa-icon\">\uD83D\uDCE7</span>\n      <div>\n        <div class=\"mfa-card__title\">Restablecer autenticador por correo</div>\n        <div class=\"mfa-card__sub\">Enviaremos un c\u00F3digo a su correo institucional</div>\n      </div>\n      <button class=\"mfa-close-btn\" type=\"button\"\n              (click)=\"openModal('verify')\"\n              [disabled]=\"mfaLoading\"\n              title=\"Volver a la verificaci\u00F3n\"\n              aria-label=\"Cerrar\">\n        <i class=\"fa-solid fa-xmark\"></i>\n      </button>\n    </div>\n\n    <div class=\"mfa-card__body\">\n\n      <!-- Paso 1: solicitar el c\u00F3digo -->\n      <div *ngIf=\"resetStep === 1\">\n        <p class=\"mfa-help\">\n          El c\u00F3digo dura <strong>5 minutos</strong>. Por seguridad, luego de validarlo habr\u00E1\n          una espera breve antes de poder enrolar nuevamente.\n        </p>\n        <p *ngIf=\"mfaError\" class=\"mfa-error-inline\">{{ mfaError }}</p>\n        <div class=\"mfa-actions\">\n          <button class=\"mfa-btn mfa-btn--primary\" (click)=\"submitResetRequest()\" [disabled]=\"mfaLoading\">\n            <span *ngIf=\"!mfaLoading\"><i class=\"fa fa-envelope\"></i> Enviar c\u00F3digo al correo</span>\n            <span *ngIf=\"mfaLoading\"><i class=\"fa fa-spinner fa-spin\"></i> Enviando...</span>\n          </button>\n        </div>\n      </div>\n\n      <!-- Paso 2: ingresar el c\u00F3digo recibido -->\n      <div *ngIf=\"resetStep === 2\">\n        <p class=\"mfa-help\">Ingrese el c\u00F3digo de <strong>6 d\u00EDgitos</strong> que lleg\u00F3 a su correo.</p>\n        <p *ngIf=\"resetInfo\" class=\"mfa-info-inline\">{{ resetInfo }}</p>\n\n        <div class=\"mfa-otp-wrap\">\n          <input *ngFor=\"let d of otpDigits; let i = index; trackBy: trackByIdx\"\n                 class=\"mfa-otp-box\" type=\"text\" inputmode=\"numeric\"\n                 maxlength=\"1\" [value]=\"d\"\n                 [attr.autocomplete]=\"i === 0 ? 'one-time-code' : 'off'\"\n                 (input)=\"onOtpInput(i, $event)\"\n                 (keydown)=\"onOtpKeydown(i, $event)\"\n                 (paste)=\"onOtpPaste($event)\"\n                 [disabled]=\"mfaLoading\">\n        </div>\n\n        <p *ngIf=\"mfaError\" class=\"mfa-error-inline\">{{ mfaError }}</p>\n\n        <div class=\"mfa-actions\">\n          <button class=\"mfa-btn mfa-btn--primary\" (click)=\"submitResetConfirm()\"\n                  [disabled]=\"mfaLoading || otpCode.length < 6\">\n            <span *ngIf=\"!mfaLoading\">Confirmar c\u00F3digo</span>\n            <span *ngIf=\"mfaLoading\"><i class=\"fa fa-spinner fa-spin\"></i> Verificando...</span>\n          </button>\n          <button class=\"mfa-btn mfa-btn--ghost\" (click)=\"resetStep = 1; clearOtp(); mfaError = ''\"\n                  [disabled]=\"mfaLoading\">\n            \u2190 Volver\n          </button>\n        </div>\n      </div>\n\n      <div class=\"mfa-divider\"></div>\n      <div class=\"mfa-lost-link\">\n        <button type=\"button\" (click)=\"openModal('verify')\">\u2190 Volver a la verificaci\u00F3n</button>\n      </div>\n    </div>\n  </div>\n\n  <!-- \u2500\u2500 MODAL: BLOQUEADO \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div *ngIf=\"mfaModal === 'blocked'\" class=\"mfa-card mfa-card--danger\">\n    <div class=\"mfa-card__head\">\n      <span class=\"mfa-icon\">\u26D4</span>\n      <div>\n        <div class=\"mfa-card__title\">Acceso temporalmente bloqueado</div>\n        <div class=\"mfa-card__sub\">Se detectaron intentos fallidos</div>\n      </div>\n      <button class=\"mfa-close-btn\" type=\"button\"\n              (click)=\"cancelMfa()\"\n              title=\"Volver al inicio de sesi\u00F3n\"\n              aria-label=\"Cerrar\">\n        <i class=\"fa-solid fa-xmark\"></i>\n      </button>\n    </div>\n\n    <div class=\"mfa-card__body\">\n      <p class=\"mfa-help\">\n        Su cuenta tiene un bloqueo de seguridad activo por m\u00FAltiples intentos fallidos.\n        Espere a que expire el tiempo de bloqueo e intente nuevamente.\n      </p>\n      <div class=\"mfa-blocked-until\">\n        <i class=\"fa-solid fa-clock\"></i>\n        Bloqueado hasta: <strong>{{ mfaBloqueoHasta || 'No disponible' }}</strong>\n      </div>\n      <div class=\"mfa-actions mfa-actions--center\">\n        <button class=\"mfa-btn mfa-btn--ghost\" (click)=\"cancelMfa()\">\n          Volver al inicio de sesi\u00F3n\n        </button>\n      </div>\n    </div>\n  </div>\n\n  <!-- \u2500\u2500 MODAL: SERVICIO CA\u00CDDO \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div *ngIf=\"mfaModal === 'svcdown'\" class=\"mfa-card mfa-card--warning\">\n    <div class=\"mfa-card__head\">\n      <span class=\"mfa-icon\">\u26A0\uFE0F</span>\n      <div>\n        <div class=\"mfa-card__title\">Servicio de doble autenticaci\u00F3n no disponible</div>\n        <div class=\"mfa-card__sub\">No es posible iniciar sesi\u00F3n en este momento</div>\n      </div>\n      <button class=\"mfa-close-btn\" type=\"button\"\n              (click)=\"cancelMfa()\"\n              title=\"Volver al inicio de sesi\u00F3n\"\n              aria-label=\"Cerrar\">\n        <i class=\"fa-solid fa-xmark\"></i>\n      </button>\n    </div>\n\n    <div class=\"mfa-card__body\">\n      <p class=\"mfa-help\">\n        El servicio de <strong>Doble Autenticaci\u00F3n (2FA/MFA)</strong> est\u00E1 presentando\n        fallas o no se pudo establecer conexi\u00F3n. Por pol\u00EDtica de seguridad, el acceso\n        queda temporalmente restringido hasta que el servicio se restablezca.\n      </p>\n      <p *ngIf=\"mfaSvcMsg\" class=\"mfa-error-inline\">{{ mfaSvcMsg }}</p>\n      <div class=\"mfa-note mfa-note--warning\">\n        <strong>Acci\u00F3n requerida:</strong> Contacte al Administrador del sistema o al t\u00E9cnico GUTIC de su unidad.\n      </div>\n      <div class=\"mfa-actions mfa-actions--center\">\n        <button class=\"mfa-btn mfa-btn--ghost\" (click)=\"cancelMfa()\">\n          Volver al inicio de sesi\u00F3n\n        </button>\n      </div>\n    </div>\n  </div>\n\n</div><!-- /mfa-overlay -->\n", styles: ["@charset \"UTF-8\";.mfa-overlay{position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;background:#02061799;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);padding:16px;animation:mfaOverlayIn .2s ease-out}@keyframes mfaOverlayIn{0%{opacity:0}to{opacity:1}}.mfa-card{background:#fff;border:1px solid rgba(255,255,255,.12);border-radius:18px;box-shadow:0 30px 80px #02061761;width:100%;max-width:500px;max-height:90vh;overflow-y:auto;animation:mfaCardIn .22s ease-out}.mfa-card--lg{max-width:840px}.mfa-card--danger .mfa-card__head{background:linear-gradient(135deg,#7f1d1d,#dc2626)}.mfa-card--warning .mfa-card__head{background:linear-gradient(135deg,#005478,#0e1f38)}.mfa-card__head{display:flex;align-items:center;gap:14px;padding:18px 50px 18px 22px;background:linear-gradient(135deg,#03173d,#1c45b4);border-radius:18px 18px 0 0;color:#fff;position:relative}.mfa-card__title{font-weight:800;font-size:calc(15px * var(--font-size-scale, 1));line-height:1.2;letter-spacing:.1px}.mfa-card__sub{font-size:calc(12px * var(--font-size-scale, 1));opacity:.72;margin-top:3px;font-weight:400}.mfa-card__body{padding:22px}.mfa-close-btn{position:absolute;top:12px;right:12px;width:32px;height:32px;border:none;border-radius:50%;background:#ffffff26;color:#ffffffd9;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:15px;line-height:1;transition:background .15s,color .15s,transform .12s;flex-shrink:0}.mfa-close-btn:hover:not(:disabled){background:#ffffff47;color:#fff;transform:scale(1.08)}.mfa-close-btn:active:not(:disabled){transform:scale(.95)}.mfa-close-btn:disabled{opacity:.35;cursor:not-allowed}@keyframes mfaCardIn{0%{opacity:0;transform:translateY(10px) scale(.99)}to{opacity:1;transform:translateY(0) scale(1)}}.mfa-icon{font-size:1.5rem;flex-shrink:0;line-height:1}.mfa-help{color:var(--policia-neutral-oscuro, #53565a);font-size:calc(13px * var(--font-size-scale, 1));line-height:1.5;margin:0 0 14px}.mfa-step-label{font-weight:800;font-size:calc(13px * var(--font-size-scale, 1));color:var(--policia-medio, #002a66);margin:0 0 6px;letter-spacing:.1px}.mfa-step-label--sm{font-size:calc(12px * var(--font-size-scale, 1));margin-top:14px}.mfa-enroll-grid{display:grid;grid-template-columns:1fr 1fr;gap:22px}@media(max-width:640px){.mfa-enroll-grid{grid-template-columns:1fr}}.mfa-qr-wrap{text-align:center;margin-bottom:14px}.mfa-qr{max-width:210px;width:100%;border-radius:var(--ui-radius, 14px);border:2px solid rgba(21,27,59,.14);padding:8px;background:#fff;box-shadow:0 6px 16px #0206171a}.mfa-manual-wrap{margin-top:12px}.mfa-manual-key{display:block;background:var(--policia-oscuro, #151b3b);color:#cdff00;font-family:Courier New,monospace;font-size:.82rem;padding:10px 14px;border-radius:var(--ui-radius-sm, 10px);word-break:break-all;margin-top:4px;letter-spacing:.05em;border:1px solid rgba(205,255,0,.2)}.mfa-otpauth-btn{display:inline-flex;align-items:center;gap:8px;margin-top:12px;padding:9px 14px;border-radius:var(--ui-radius-sm, 10px);border:1px solid var(--ui-border, rgba(21, 27, 59, .18));background:var(--ui-surface, #fff);color:var(--policia-oscuro, #151b3b);font-size:.82rem;font-weight:600;text-decoration:none;cursor:pointer;transition:background .15s,border-color .15s}.mfa-otpauth-btn i{color:var(--policia-azul, #2563eb)}.mfa-otpauth-btn:hover{background:var(--policia-gradiente-soft, rgba(37, 99, 235, .08));border-color:var(--policia-azul, #2563eb)}html.dark-mode .mfa-otpauth-btn{background:#ffffff0d;border-color:#ffffff26;color:#e4e7ebe6}.mfa-otp-wrap{display:flex;gap:8px;justify-content:center;margin:18px 0}.mfa-otp-box{width:48px;height:56px;text-align:center;font-size:1.5rem;font-weight:800;border-radius:12px;border:1.5px solid rgba(21,27,59,.18);background:#fff;color:var(--policia-medio, #002a66);outline:none;transition:border-color .15s ease,box-shadow .15s ease;caret-color:transparent;font-family:Montserrat,sans-serif}.mfa-otp-box:focus{border-color:#08a6cbbf;box-shadow:0 0 0 4px #08a6cb2e}.mfa-otp-box:hover:not(:focus):not(:disabled){border-color:#151b3b4d}.mfa-otp-box:disabled{opacity:.5;cursor:not-allowed}@media(max-width:420px){.mfa-otp-box{width:40px;height:50px;font-size:1.25rem}}.mfa-remember-label{display:flex;align-items:center;gap:10px;font-size:calc(13px * var(--font-size-scale, 1));color:var(--policia-neutral-oscuro, #53565a);cursor:pointer;margin-bottom:16px;padding:10px 12px;border:1px solid rgba(21,27,59,.12);border-radius:999px;background:#151b3b08;transition:background .15s ease,border-color .15s ease}.mfa-remember-label:hover{background:#08a6cb0f;border-color:#08a6cb40}.mfa-remember-label input[type=checkbox]{width:17px;height:17px;accent-color:#cdff00;cursor:pointer;border-radius:5px}.mfa-actions{display:flex;flex-direction:column;gap:10px;margin-top:18px}.mfa-actions--center{align-items:center}.mfa-btn{display:flex;align-items:center;justify-content:center;gap:8px;padding:0 20px;height:42px;border-radius:var(--btn-radius, 12px);border:1.5px solid transparent;font-size:calc(14px * var(--font-size-scale, 1));font-weight:800;letter-spacing:.2px;cursor:pointer;transition:transform .15s ease,box-shadow .15s ease,background .15s ease;font-family:Montserrat,sans-serif}.mfa-btn:disabled{opacity:.5;cursor:not-allowed;transform:none!important}.mfa-btn:focus-visible{outline:none;box-shadow:0 0 0 4px #08a6cb38}.mfa-btn--primary{background:#cdff00;color:#151b3b;border-color:#cdff008c;box-shadow:0 8px 20px #02061724}.mfa-btn--primary:hover:not(:disabled){background:#d8ff2a;transform:translateY(-1px);box-shadow:0 12px 26px #0206172e}.mfa-btn--primary:active:not(:disabled){transform:translateY(0);box-shadow:none}.mfa-btn--ghost{background:var(--policia-medio, #002a66);color:#fff;border-color:#ffffff24;box-shadow:0 4px 12px #0206172e}.mfa-btn--ghost:hover:not(:disabled){background:#003580;transform:translateY(-1px);box-shadow:0 8px 18px #02061738}.mfa-btn--ghost:active:not(:disabled){transform:translateY(0)}.mfa-error-inline{background:#ef44441a;color:#991b1b;border:1px solid rgba(239,68,68,.28);border-left:3px solid #ef4444;border-radius:var(--ui-radius-sm, 10px);padding:10px 14px;font-size:calc(12px * var(--font-size-scale, 1));font-weight:600;margin:10px 0}.mfa-info-inline{background:#08a6cb1a;color:var(--policia-medio, #002a66);border:1px solid rgba(8,166,203,.3);border-left:3px solid #08a6cb;border-radius:var(--ui-radius-sm, 10px);padding:10px 14px;font-size:calc(12px * var(--font-size-scale, 1));font-weight:600;margin:10px 0}.mfa-divider{height:1px;background:#151b3b1a;margin:20px 0}.mfa-lost-link{text-align:center}.mfa-lost-link button{background:none;border:none;color:var(--policia-cielo, #08a6cb);font-size:calc(12px * var(--font-size-scale, 1));font-weight:700;cursor:pointer;padding:0;font-family:Montserrat,sans-serif;transition:color .15s ease;letter-spacing:.1px}.mfa-lost-link button i{margin-right:5px}.mfa-lost-link button:hover{color:var(--policia-claro, #1c45b4);text-decoration:underline}.mfa-note{background:#b36e1a14;border:1px solid rgba(179,110,26,.25);border-left:3px solid #b36e1a;border-radius:var(--ui-radius-sm, 10px);padding:10px 14px;font-size:calc(12px * var(--font-size-scale, 1));color:#7a3f05;margin-top:16px}.mfa-note i{margin-right:6px;color:#b36e1a}.mfa-note--warning{background:#b36e1a1a;color:#92400e}.mfa-blocked-until{display:flex;align-items:center;gap:10px;background:#ef444414;border:1px solid rgba(239,68,68,.22);border-left:3px solid #ef4444;border-radius:var(--ui-radius, 14px);padding:14px 18px;font-size:calc(14px * var(--font-size-scale, 1));color:#7f1d1d;margin:14px 0 20px;font-weight:600}.mfa-blocked-until i{color:#ef4444;font-size:1.1rem;flex-shrink:0}.mfa-card{scrollbar-width:thin;scrollbar-color:rgba(8,166,203,.25) transparent}.mfa-card::-webkit-scrollbar{width:5px}.mfa-card::-webkit-scrollbar-track{background:transparent}.mfa-card::-webkit-scrollbar-thumb{background:#08a6cb4d;border-radius:999px}\n"] }]
        }], ctorParameters: () => [{ type: MfaService }, { type: i2.DomSanitizer }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [POLICIA_MFA_CONFIG]
                }] }], propDecorators: { challenge: [{
                type: Input
            }], usuario: [{
                type: Input
            }], autenticado: [{
                type: Output
            }], cancelado: [{
                type: Output
            }] } });

/*
 * @policia/mfa — API pública de la librería de doble autenticación institucional.
 *
 * Punto de entrada único del paquete: los sistemas consumidores importan solo
 * desde `@policia/mfa`. Este archivo es el `entryFile` que ng-packagr empaqueta.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MfaService, POLICIA_MFA_CONFIG, PoliciaMfaFlowComponent, providePoliciaMfa };
//# sourceMappingURL=policia-mfa.mjs.map
