import * as i0 from '@angular/core';
import { InjectionToken, Provider, OnChanges, EventEmitter, SimpleChanges } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SafeUrl, DomSanitizer } from '@angular/platform-browser';

/**
 * Configuración de la librería de doble autenticación (@policia/mfa).
 *
 * Cada sistema que consuma la librería la provee con su propia URL de API.
 * La lógica y las modales de 2FA son idénticas en todos los sistemas; solo
 * cambia esta configuración.
 */
interface PoliciaMfaConfig {
    /** Base URL de la API del sistema (ej. environment.apiBaseUrl → ".../api"). */
    apiBaseUrl: string;
    /**
     * Segmento del controlador del backend que expone los endpoints MFA
     * (MfaVerify, MfaEnrollConfirm, MfaResetRequest, MfaResetConfirm).
     * Por defecto "Cuenta" (como en SECAD).
     */
    controlador?: string;
    /**
     * Emisor mostrado en la app de autenticación y en el enlace otpauth://
     * al enrolar (ej. "SECAD"). Por defecto "SECAD".
     */
    issuer?: string;
    /**
     * Clave de localStorage donde se persiste el UUID del dispositivo (para
     * "recordar este equipo"). Por defecto "policia_mfa_device".
     * SECAD usa "secad_mfa_device" para no invalidar dispositivos ya recordados.
     */
    deviceStorageKey?: string;
}
/** Token de inyección con la configuración efectiva (defaults aplicados). */
declare const POLICIA_MFA_CONFIG: InjectionToken<Required<PoliciaMfaConfig>>;
/**
 * Registra la librería MFA en el sistema consumidor.
 *
 * Uso (en app.config.ts / providers de bootstrap):
 * ```ts
 * providePoliciaMfa({ apiBaseUrl: environment.apiBaseUrl })
 * ```
 */
declare function providePoliciaMfa(config: PoliciaMfaConfig): Provider;

/**
 * Respuesta del primer paso del login cuando el backend exige MFA
 * (POST .../{controlador}/Token con RequiresMfa=true).
 */
interface MfaLoginChallenge {
    success: false;
    requiresMfa: true;
    /** 'enroll' | 'verify' | 'blocked' | 'svcdown' */
    mfaMode: string;
    mfaSessionToken?: string;
    mfaQrBase64?: string;
    mfaManualKey?: string;
    mfaEnrollToken?: string;
    bloqueoHasta?: string;
    message?: string;
}
/** Respuesta de los pasos MFA intermedios (verify, enroll-confirm, reset*). */
interface MfaStepResponse {
    success: boolean;
    message: string;
    /** JWT definitivo — presente solo cuando success=true y el 2FA quedó completo. */
    token?: string;
    bloqueoHasta?: string;
    isInfo?: boolean;
    /** QR para abrir modal de enrolamiento tras un reset exitoso. */
    qrBase64?: string;
    manualKey?: string;
    enrollToken?: string;
}

/**
 * Cliente del flujo de doble autenticación institucional (@policia/mfa).
 *
 * Consume los endpoints MFA del backend del propio sistema
 * (.../{controlador}/MfaVerify, MfaEnrollConfirm, MfaResetRequest,
 * MfaResetConfirm), que a su vez se integran con la API 2FA central de la
 * Policía. La URL y el controlador se toman de la configuración inyectada,
 * así la misma librería sirve para cualquier sistema.
 */
declare class MfaService {
    private http;
    private cfg;
    private readonly base;
    private readonly deviceKey;
    constructor(http: HttpClient, cfg: Required<PoliciaMfaConfig>);
    /** Obtiene (o genera y persiste) el UUID del dispositivo actual. */
    getDeviceId(): string;
    private uuid;
    /** Verificar código TOTP. Puede recibir deviceId para recordar el equipo. */
    verify(mfaSessionToken: string, code: string, rememberDevice: boolean): Observable<MfaStepResponse>;
    /** Confirmar el primer enrolamiento (usuario escaneó QR y escribió el código). */
    enrollConfirm(mfaSessionToken: string, code: string, enrollToken: string): Observable<MfaStepResponse>;
    /** Solicitar código de reset al correo institucional. */
    resetRequest(mfaSessionToken: string): Observable<MfaStepResponse>;
    /** Confirmar código de correo → resetea MFA → devuelve nuevo QR para enrolar. */
    resetConfirm(mfaSessionToken: string, code: string): Observable<MfaStepResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MfaService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MfaService>;
}

type MfaModal = 'enroll' | 'verify' | 'reset' | 'blocked' | 'svcdown' | null;
/**
 * Componente reutilizable con las modales del flujo de doble autenticación
 * institucional (@policia/mfa): enrolamiento (QR + clave manual + botón otpauth
 * de un toque), verificación TOTP, reset por correo, bloqueo y servicio caído.
 *
 * Uso desde el login de un sistema:
 * ```html
 * <pmfa-flow [challenge]="mfaChallenge" [usuario]="usuario"
 *            (autenticado)="onMfaOk($event)" (cancelado)="mfaChallenge = null">
 * </pmfa-flow>
 * ```
 * El componente NO navega ni guarda el JWT: emite el token vía `autenticado`
 * para que el sistema consumidor decida qué hacer (guardar sesión, redirigir…).
 */
declare class PoliciaMfaFlowComponent implements OnChanges {
    private mfaService;
    private sanitizer;
    private cfg;
    /** Reto MFA recibido en el paso 1 del login. Al asignarse, abre la modal correcta. */
    challenge: MfaLoginChallenge | null;
    /** Usuario en sesión — se usa como etiqueta del enlace otpauth. */
    usuario: string;
    /** Emite el JWT definitivo cuando el 2FA se completa con éxito. */
    autenticado: EventEmitter<string>;
    /** Emite cuando el usuario cancela / cierra el flujo. */
    cancelado: EventEmitter<void>;
    mfaModal: MfaModal;
    mfaSessionToken: string;
    mfaQrBase64: string;
    mfaManualKey: string;
    mfaEnrollToken: string;
    mfaOtpauthUri: SafeUrl | null;
    mfaBloqueoHasta: string;
    mfaSvcMsg: string;
    otpDigits: string[];
    mfaRememberDevice: boolean;
    mfaLoading: boolean;
    mfaError: string;
    mfaInfo: string;
    resetStep: number;
    resetInfo: string;
    constructor(mfaService: MfaService, sanitizer: DomSanitizer, cfg: Required<PoliciaMfaConfig>);
    ngOnChanges(changes: SimpleChanges): void;
    private buildOtpauthUri;
    private handleMfaChallenge;
    openModal(m: MfaModal): void;
    closeModal(): void;
    openResetModal(): void;
    cancelMfa(): void;
    clearOtp(): void;
    get otpCode(): string;
    onOtpInput(idx: number, event: Event): void;
    onOtpKeydown(idx: number, event: KeyboardEvent): void;
    onOtpPaste(event: ClipboardEvent): void;
    private focusOtp;
    private onOtpComplete;
    submitVerify(): void;
    submitEnroll(): void;
    submitResetRequest(): void;
    submitResetConfirm(): void;
    private handleStepResponse;
    trackByIdx(idx: number): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<PoliciaMfaFlowComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PoliciaMfaFlowComponent, "pmfa-flow", never, { "challenge": { "alias": "challenge"; "required": false; }; "usuario": { "alias": "usuario"; "required": false; }; }, { "autenticado": "autenticado"; "cancelado": "cancelado"; }, never, never, true, never>;
}

export { MfaService, POLICIA_MFA_CONFIG, PoliciaMfaFlowComponent, providePoliciaMfa };
export type { MfaLoginChallenge, MfaStepResponse, PoliciaMfaConfig };
